INPUT DATA
==========
State: 	Inactive
Run: 	Run_162
Frame: 	2384

OUTPUT DATA
==========
Run name: 	/home/diego/Minerva/Kristen_Dimers/Inactive/Phase_1/Run_162/5-Production/2016-04-19/traj_comp.xtc
Frame in run: 	577

ADDITIONAL DATA
==========
Distance: 	44.0019813728
Ang1: 	-1.58121674265
Ang2: 	-1.2837357738
