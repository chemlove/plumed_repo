#!/usr/local/bin/python2.7
# encoding: utf-8
'''
This script allows to modify GROMACS itp files to rescale the weight of hydrogen atoms and repartitions the mass from the bonded heavy atoms. 


@author:     Sebastian Schneider

@copyright:  2015 Filizola Lab @ Icahn School of Medicine. All rights reserved.

@license:    license

@contact:    user_email
@deffield    updated: Updated
'''

import sys
import os

from argparse import ArgumentParser
from argparse import RawDescriptionHelpFormatter

__all__ = []
__version__ = 0.1
__date__ = '2015-12-16'
__updated__ = '2015-12-16'

DEBUG = 0
TESTRUN = 0
PROFILE = 0

HYDROGEN_WEIGHT = 1.008
 
class CLIError(Exception):
    '''Generic exception to raise and log different fatal errors.'''
    def __init__(self, msg):
        super(CLIError).__init__(type(self))
        self.msg = "E: %s" % msg
    def __str__(self):
        return self.msg
    def __unicode__(self):
        return self.msg

class Atom:
    """
    Wrapper class to store the basic information that are going to be changed.
    Only the atom ID, the weight and type are necessary to store. The rest 
    will be taken from the itp file on the fly 
    """
        
    def __init__(self, atom_id, weight, atom_type):
        """
        @param atom_id: The id of the atom as given in the first column of the itp file
        @param weight: The weight of the atom 
        @param atom_type: The atom type.   
        """
        self.id = atom_id
        self.weight = weight
        self.type = atom_type
    
    def getWeight(self):                
        """
        returns the weight of the Atom
        @return: Float, returns the weight of the Atom        
        """
        return self.weight
    
    def setWeight(self, weight):
        """
        Sets the weight of the Atom. Simple value check. 
        @param weight: Float, new weight of the Atom 
        """
        if weight <= 0.0:
            print "WARNING, atom ", self.id, "has a zero or subzero weight"
        self.weight = weight
    
    def isHydrogen(self):
        """
        Returns True if the Atom if of type Hydrogen 
        @return: Boolean
        """
        if self.type == "H":
            return True
        else:
            return False

class HeavyAtom:
    """
    Wrapper class for the heavy atoms which are bonded to a hydrogen atom. 
    """
    
    
    def __init__(self, atom, hydrogens):
        """
        Creates a HeavyAtom object
        @param atom: Atom object
        @param hydrogens: List of Atom objects or empty list.  
        """
        self.atom = atom
        if type(hydrogens) is list:
            self.hydrogens = hydrogens
        else:
            print "NOTE: hydrogens was not initialized as a list"
            print "will be cast to list automatically."
        
    def reweight(self, factor):
        """
        reweights the weight of the associated atom by the number of hydrogens        
        before reweighting, connect the bonds!
        @param factor: Float. Scaling factor for the hydrogen scaling and heavy atom mass repartitioning.  
        """
        
        w = self.atom.getWeight()
        scaling = HYDROGEN_WEIGHT * (factor - 1.0) 
        w -= scaling * len(self.hydrogens)
        self.atom.setWeight(w)


    def addHydrogen(self, atom):
        """
        Adds hydrogen to the heavy atom by attaching the hydrogen to self.hydrogens list
        @param atom: Atom object 
        """
        
        if type(self.hydrogens) is list:
            self.hydrogens.append(atom)
        else:
            print "NOTE: automatic initialization of the hydrogen list"
            self.hydrogens = [atom]


def getPartInbetween(itpfile, beg, end):
    """
    reads in lines within two given identifiers, marking the beginning and the end of 
    a the segment to be read in. Will return a list of strings (lines).
    @param itpfile: String, filename of the itp file
    @param beg: String, should be a unique identifier in the itp file from which on the reading is started.
    @param end: String, should be an identifier in the itp file after which reading in is stopped.   
    @return: List of strings
    """
    reading = False
    outlines = []
    for line in open(itpfile):
        if line.find(beg) != -1:  # section to read in starts at atoms
            reading = True
            continue
        if line.find(end) != -1:  # stop reading in when atom section is over
            reading = False
        if reading == True and line.strip().find(";") != 0 and len(line.strip()) > 1:  # read the wanted lines, skip comments            
            outlines.append(line)
    return outlines


def readInAtoms(itpfile):
    """
    reads in atom section of the itp file    
    @param itpfile: String, filename of the itp file
    @return: Dictionary with key: atom_nr (as in the itp file), value: Atom
    """    
    atoms = {}
    lines = getPartInbetween(itpfile, "[ atoms ]", "[ bonds ]")
    for line in lines:                        
        ele = line.split(";")[0].split()
        """
        create an atom
        @TODO: I don't like the splitting since this might not always be the same. But the format based on columns differs often, so
        this is no option. 
        """
        atoms[int(ele[0])] = Atom(int(ele[0]), float(ele[-1]), ele[4][0])
        # print int(ele[0]), float(ele[-1]), ele[4][0], atoms[int(ele[0])].isHydrogen()
    print "Got", len(atoms), "atoms"
    return atoms
    
        
def getHeavyAtomsWithHydrogens(itpfile, atoms):
    """
    Read in the bond section, create the heavy atoms with the associated hydrogen bonds.
    Heavy atoms lacking a bound hydrogen will not be added to the return dictionary.
    @param itpfile: String, filename of the itp file 
    @param atoms: Dictionary with Atom objects, key is the ID of the Atom object, value is the Atom object 
    @return: Dictionary with keys the ID of the HeavyAtom and value the HeavyAtom     
    """
    heavy_atoms = {}   
    lines = getPartInbetween(itpfile, "[ bonds ]", "[")
    for line in lines:                    
        ele = line.split(";")[0].split()
                    
        # identify which index is the heavy atom
        id1 = int(ele[0])
        id2 = int(ele[1])
        heavy_id = -1
        hydrogen_id = -1
        if atoms[id1].type != "H":
            heavy_id = id1 
        else:
            hydrogen_id = id1
        if atoms[id2].type != "H":
            heavy_id = id2
        else:
            hydrogen_id = id2
            
        # if it is a bond between heavy atoms, just continue
        if hydrogen_id == -1:  
            continue
        
        # generate heavy atom if it does not exist
        if heavy_id not in heavy_atoms:
            heavy_atoms[heavy_id] = HeavyAtom(atoms[heavy_id], [])
        heavy_atoms[heavy_id].addHydrogen(atoms[hydrogen_id])  # add the hydrogen to the heavy atom
    print "Got", len(heavy_atoms), "heavy atoms bond to hydrogens."            
    return heavy_atoms
    
    
     
def getReweightedTopology(itpfile, atoms, heavy_atoms):
    """
    Reads in the itp file and changes the weight if necessary. Will return a list of strings which
    can be written or printed out.
    
    @param atoms: Dictionary with Atom objects, key is the ID of the Atom object, value is the Atom object
    @param heavy_atoms: Dictionary with HeavyAtom objects, key is the ID of the associated Atom object, value is the HeavyAtom object
    @param itpfile: String, filename of the itp file
    @return: List of strings. Returns a list of strings representing the lines of the itp file. 
    """
    reading = False
    outlines = []
    total_w = 0.0
    original_w = 0.0
    for line in open(itpfile):
        if line.find("[ atoms ]") != -1:  # section to read in starts at atoms
            outlines.append(line)
            reading = True
            continue
        if line.find("[") != -1:  # stop reading in when atom section is over
            outlines.append(line)
            reading = False
            continue
        if reading == True and len(line.strip()) > 1 and line.strip().find(";") != 0:  # atom section, skipping comments and blank lines
            ele = line.split()
            id1 = int(ele[0])
            w = -1
            if atoms[id1].isHydrogen() == True:  # hydrogen atom
                w = float(ele[7]) * 4.0
            elif id1 not in heavy_atoms:  # heavy atom without an attached hydrogen
                w = float(ele[7]) 
            else:  # heavy atom with a hydrogen
                w = heavy_atoms[id1].atom.getWeight()
            total_w += float(str(("%10.4f") % (w)))
            original_w += float(ele[7])
            outlines.append(str("%6s %10s %6s   %6s %6s %6s %10s %10.4f \n") % (ele[0], ele[1], ele[2], ele[3], ele[4], ele[5], ele[6], w))
        else:
            outlines.append(line)
    print "NOTE: Please check if the weights are the same, there might be differences due to rounding. Adjust by hand if necessary"
    print "Sum of old weights:", original_w
    print "Sum of new weights:", total_w
    if str(("%10.4f") % (original_w)) == str(("%10.4f") % (total_w)):  # convert to string using the standard precision to avoid float comparison issues
        print "I guess we are ok on the weight site..."
    else:
        print "Note: Weights differ"
    
    return outlines
            


def main(argv=None):  # IGNORE:C0111
    '''Command line options.'''

    if argv is None:
        argv = sys.argv
    else:
        sys.argv.extend(argv)

    program_name = os.path.basename(sys.argv[0])
    program_version = "v%s" % __version__
    program_build_date = str(__updated__)
    program_version_message = '%%(prog)s %s (%s)' % (program_version, program_build_date)
    program_shortdesc = __import__('__main__').__doc__.split("\n")[1]
    program_license = '''%s

  Created by Sebastian Schneider on %s.
  Copyright 2015 %s. All rights reserved.

  Licensed under the Apache License 2.0
  http://www.apache.org/licenses/LICENSE-2.0

  Distributed on an "AS IS" basis without warranties
  or conditions of any kind, either express or implied.
  
 
The mass of the attached heavy atom will be reduced by (factor-1.0)*H_weight*N_hydrogens. Per default, the factor is 4 times the regular hydrogen mass but can be adjusted with -f. 
''' % (program_shortdesc, str(__date__), "Filizola Lab @ Icahn School of Medicine")

    #try:
    if True:
        # Setup argument parser
        parser = ArgumentParser(description=program_license, formatter_class=RawDescriptionHelpFormatter)
        parser.add_argument("-i", "--top", dest="top", help="itp file")
        parser.add_argument("-f", "--fac", dest="factor", default=4.0, help="repartitioning factor")
        parser.add_argument("-o", "--out", dest="outfile", help="set output path", default="new.itp")                
        # Process arguments
        args = parser.parse_args()

        atoms = readInAtoms(args.top)
        heavy_atoms = getHeavyAtomsWithHydrogens(args.top, atoms)
        
        for atom_id, atom in heavy_atoms.iteritems():
            atom.reweight(args.factor)
                
        outlines = getReweightedTopology(args.top, atoms, heavy_atoms)
        file(args.outfile, "wb").write("".join(outlines))
        
        
    """    
        return 0
    except KeyboardInterrupt:
        ### handle keyboard interrupt ###
        return 0
    except Exception, e:
        if DEBUG or TESTRUN:
            raise(e)
        indent = len(program_name) * " "
        sys.stderr.write(program_name + ": " + repr(e) + "\n")
        sys.stderr.write(indent + "  for help use --help")
        return 2
    """
if __name__ == "__main__":
    if DEBUG:
        sys.argv.append("-h")
        sys.argv.append("-v")
        sys.argv.append("-r")
    if TESTRUN:
        import doctest
        doctest.testmod()
    if PROFILE:
        import cProfile
        import pstats
        profile_filename = 'Activation.hydrogenRepartitioningForCHARMMLigands_profile.txt'
        cProfile.run('main()', profile_filename)
        statsfile = open("profile_stats.txt", "wb")
        p = pstats.Stats(profile_filename, stream=statsfile)
        stats = p.strip_dirs().sort_stats('cumulative')
        stats.print_stats()
        statsfile.close()
        sys.exit(0)
    sys.exit(main())
